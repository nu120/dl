hawkbitcfg
=============

sendtohawkbit is a small tool that tries to connect to a running instance
of SWUpdate and configures Hawkbit's parameter. Currently, only the the polling time
is supported.

DESCRIPTION
-----------

swupdate-hawkbitcfg <polling time>
