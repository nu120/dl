progress
========

progress that tries to connect to a running instance
of SWUpdate to get the status of a running update.

SYNOPYS
-------

swupdate-progress [option]

DESCRIPTION
-----------

-r
        optionally reboot the target after a successful update
-w
        waits for a SWUpdate connection instead of exit with error
        
