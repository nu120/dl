sendtohawkbit
=============

sendtohawkbit is a small tool that tries to connect to a running instance
of SWUpdate and uses it as proxy to send data to the Hawkbit Server.
A typical use case is after a new software was installed but it is
required the acknowledge by an application or by an operator to activate it.
The tool can forward the result for the activation to the Hawkbit server.

DESCRIPTION
-----------

swupdate-sendtohawkbit <action id> <status> <finished> <execution> <detail 1> <detail 2> ..

See Hawkbit API to get more info on the single fields.
